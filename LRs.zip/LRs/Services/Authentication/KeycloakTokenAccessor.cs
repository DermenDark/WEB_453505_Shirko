﻿using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json.Serialization;
using LRs.HelperClasses;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;

namespace LRs.Services.Authentication;

public sealed class KeycloakTokenAccessor : ITokenAccessor
{
    private readonly IHttpContextAccessor _httpContextAccessor;
    private readonly KeycloakData _keycloakData;
    private readonly HttpClient _httpClient;

    public KeycloakTokenAccessor(
        IHttpContextAccessor httpContextAccessor,
        IOptions<KeycloakData> keycloakOptions,
        HttpClient httpClient)
    {
        _httpContextAccessor = httpContextAccessor;
        _keycloakData = keycloakOptions.Value;
        _httpClient = httpClient;
    }

    public async Task SetAuthorizationHeaderAsync(
        HttpClient httpClient,
        bool isClient)
    {
        var token = await GetTokenAsync(isClient);

        httpClient.DefaultRequestHeaders.Authorization =
            new AuthenticationHeaderValue("Bearer", token);
    }

    private async Task<string> GetTokenAsync(bool isClient)
    {
        var context = _httpContextAccessor.HttpContext;

        if (!isClient &&
            context?.User.Identity?.IsAuthenticated == true)
        {
            var userToken = await context.GetTokenAsync("access_token");

            if (!string.IsNullOrWhiteSpace(userToken))
                return userToken;
        }

        return await GetClientTokenAsync();
    }

    private async Task<string> GetClientTokenAsync()
    {
        var host = _keycloakData.Host.TrimEnd('/');
        var realm = Uri.EscapeDataString(_keycloakData.Realm);

        var tokenUrl =
            $"{host}/realms/{realm}/protocol/openid-connect/token";

        using var content = new FormUrlEncodedContent(
            new Dictionary<string, string>
            {
                ["client_id"] = _keycloakData.ClientId,
                ["client_secret"] = _keycloakData.ClientSecret,
                ["grant_type"] = "client_credentials"
            });

        using var response =
            await _httpClient.PostAsync(tokenUrl, content);

        if (!response.IsSuccessStatusCode)
        {
            var error = await response.Content.ReadAsStringAsync();

            throw new HttpRequestException(
                $"Не удалось получить токен клиента: " +
                $"{(int)response.StatusCode} — {error}");
        }

        var result =
            await response.Content.ReadFromJsonAsync<TokenResponse>();

        if (string.IsNullOrWhiteSpace(result?.AccessToken))
        {
            throw new InvalidOperationException(
                "Keycloak не вернул access_token.");
        }

        return result.AccessToken;
    }

    private sealed class TokenResponse
    {
        [JsonPropertyName("access_token")]
        public string? AccessToken { get; set; }
    }
}